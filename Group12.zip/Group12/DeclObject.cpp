#include "DeclObject.h"

string DeclObject::getItemtype() { return itemtype; } // Returns datatype
string DeclObject::getDsName() { return dsName; }
string DeclObject::getDsType() { return dstype; }