#ifndef BINARYSEARCHTREE_H
#define BINARYSEARCHTREE_H

class DeclObject;
template <typename T>
class Variable;
template <typename T>
class operations;
template <typename T>
class Datastruct;
class Program;


#include <iostream>
#include <map>
#include <sstream>
#include <vector>
#include <iterator>
#include <string>
#include <algorithm>
#include "DeclObject.h"
#include "Variable.h"
#include "operations.h"
#include "Datastruct.h"
#include "Program.h"
using namespace std;



template <typename T>
class BinarySearchTree : public Datastruct<T>
{
private:
    struct node
    {
        T value;
        struct node *right;
        struct node *left;
    };
    struct node *root;
    vector<T> insert_order;
    int treeSize;
    void deleteTree(struct node *node)
    {
        if (node != NULL)
        {
            deleteTree(node->left);
            deleteTree(node->right);
            delete node;
        }
    }

public:
    BinarySearchTree()
    {
        this->root = NULL;
        this->treeSize = 0;
    }
    ~BinarySearchTree()
    {
        deleteTree(this->root);
    }

    void insert(T V);
    void insert(struct node **node, T V);
    void deleteNode(T V);

    struct node* findMin(struct node **node)
    {
        if ((*node)->left == NULL)
        {
            return *node;
        }
        return findMin(&(*node)->left);
    }

    void deleteNode(T V, struct node **node);

    void printInOrder();

    void printInOrder(struct node *node);

    void printPreOrder();

    void printPreOrder(struct node *node);

    void printPostOrder();

    void printPostOrder(struct node *node);

    int size();

    T getRoot() { return root->value; };

    void printRoot();

    void printDS();

    void deleteDS();

    bool searchDS(T V);

    bool searchDS(T V, struct node *node);

    void cloneDS();
};

#endif
