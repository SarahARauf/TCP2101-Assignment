
class DeclObject;
template <typename T>
class Variable;
template <typename T>
class operations;
template <typename T>
class Datastruct;
template <typename T>
class Stack;
template <typename T>
class BinarySearchTree;
template <typename T>
class SingleLinkedList;
template <typename T>
class DoubleLinkedList;
template <typename T>
class SLListCursor;
template <typename T>
class DLListCursor;
class Program;


#include <iostream>
#include <map>
#include <sstream>
#include <vector>
#include <iterator>
#include <string>
#include <algorithm>
#include "DeclObject.h"
#include "Variable.h"
#include "operations.h"
#include "Datastruct.h"
#include "Stack.h"
#include "Sll.h"
#include "Dll.h"
#include "SllCursor.h"
#include "DllCursor.h"
#include "BinarySearchTree.h"
#include "Program.h"
using namespace std;

//g++ -o main main.cpp DeclObject.cpp Variable.cpp operations.cpp Datastruct.cpp Stack.cpp Queue.cpp Program.cpp BinarySearchTree.cpp sll.cpp sllCursor.cpp dll.cpp dllCursor.cpp
//.\main.exe
int main()
{
    Program p;
    p.parseCommands();
    cout << "Program ended" << endl;
}
