#include "BinarySearchTree.h"

template class BinarySearchTree<int>;
template class BinarySearchTree<float>;
template class BinarySearchTree<double>;


template <typename T>
void BinarySearchTree<T>::insert(T V)
{
    insert(&(this->root), V);
    insert_order.push_back(V);
}

template <typename T>
void BinarySearchTree<T>::insert(struct node **node, T V)
{
    if (*node == NULL)
    {
        struct node *tmp = new struct node;
        tmp->value = V;
        tmp->left = NULL;
        tmp->right = NULL;
        *node = tmp;
        this->treeSize++;
    }
    else
    {
        if (V > (*node)->value)
        {
            insert(&(*node)->right, V);
        }
        else
        {
            insert(&(*node)->left, V);
        }
    }
}

template <typename T>
void BinarySearchTree<T>::deleteNode(T V)
{
    deleteNode(V, &root);
}



template <typename T>
void BinarySearchTree<T>::deleteNode(T V, struct node **node)
{
    if (*node == NULL)
    {
        std::cout << V << " is not found on the tree" << std::endl;
        return;
    }
    if (V < (*node)->value)
    {
        deleteNode(V, &(*node)->left);
    }
    else if (V > (*node)->value)
    {
        deleteNode(V, &(*node)->right);
    }
    else
    {
        if ((*node)->left == NULL && (*node)->right == NULL)
        {
            struct node *tmp = *node;
            *node = NULL;
            delete tmp;
        }
        else if ((*node)->left == NULL)
        {
            struct node *tmp = *node;
            *node = (*node)->right;
            delete tmp;
        }
        else if ((*node)->right == NULL)
        {
            struct node *tmp = *node;
            *node = (*node)->left;
            delete tmp;
        }
        else
        {
            struct node *tmp = findMin(&(*node)->right);
            (*node)->value = tmp->value;
            deleteNode(tmp->value, &(*node)->right);
        }
        this->treeSize--;
        cout << V << endl;
    }
}

template <typename T>
void BinarySearchTree<T>::printInOrder()
{
    printInOrder(this->root);
    std::cout << std::endl;
}

template <typename T>
void BinarySearchTree<T>::printInOrder(struct node *node)
{
    if (node != NULL)
    {
        printInOrder(node->left);
        std::cout << node->value << ":";
        printInOrder(node->right);
    }
}

template <typename T>
void BinarySearchTree<T>::printPreOrder()
{
    printPreOrder(this->root);
    std::cout << std::endl;
}

template <typename T>
void BinarySearchTree<T>::printPreOrder(struct node *node)
{
    if (node != NULL)
    {
        std::cout << node->value << ":";
        printPreOrder(node->left);
        printPreOrder(node->right);
    }
}

template <typename T>
void BinarySearchTree<T>::printPostOrder()
{
    printPostOrder(this->root);
    std::cout << std::endl;
}

template <typename T>
void BinarySearchTree<T>::printPostOrder(struct node *node)
{
    if (node != NULL)
    {
        printPostOrder(node->left);
        printPostOrder(node->right);
        std::cout << node->value << ":";
    }
}

template <typename T>
int BinarySearchTree<T>::size()
{
    return this->treeSize;
}


template <typename T>
void BinarySearchTree<T>::printRoot()
{
    cout << getRoot() << endl;
}


template <typename T>
void BinarySearchTree<T>::printDS()
{
    for (auto element : insert_order)
        cout << element << ":";
    cout << endl;
}


template <typename T>
void BinarySearchTree<T>::deleteDS()
{
    deleteTree(root);
    root = NULL;
    treeSize = 0;
    cout << endl;
    cout << "BST have been deleted" << endl;
}


template <typename T>
bool BinarySearchTree<T>::searchDS(T V)
{
    return searchDS(V, this->root);
}


template <typename T>
bool BinarySearchTree<T>::searchDS(T V, struct node *node)
{
    if (node == NULL)
    {
        cout << "FALSE" << endl;
        return false;
    }
    if (V == node->value)
    {
        cout << "TRUE" << endl;
        return true;
    }
    if (V < node->value)
    {
        return searchDS(V, node->left);
    }
    else
    {
        return searchDS(V, node->right);
    }
}


template <typename T>
void BinarySearchTree<T>::cloneDS()
{
    for (auto element : insert_order)
        cout << element << ":";
}